import time
import itertools

import data
import solution


class LocalSearch:
    def __init__(self,instance):
        self.instance = instance

    def local_search(self, start_sol, time_left):
        # To implement
        return start_sol
